# toSpcy

This package aims to initialize data for training in SpaCy!